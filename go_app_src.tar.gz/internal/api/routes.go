package api

import (
	"portaldata-api/internal/services"

	"github.com/gin-gonic/gin"
)

func SetupRoutes(router *gin.Engine, productService *services.ProductService, parserService *services.ParserService) {
	// Создаем handlers
	handlers := NewHandlers(productService, parserService, "f428fbc16a97b9e2a55717bd34e97537ec34cb8c04a5f32eeb4e88c9ee998a53")

	// Группа маршрутов для API v1
	v1 := router.Group("/v1")
	{
		// Группа маршрутов для товаров
		products := v1.Group("/products")
		{
			// Публичные маршруты (без авторизации)
			products.GET("/products.php", handlers.ListProducts)
			products.GET("/products.php/:id", handlers.GetProduct)
			products.GET("/parser.php", handlers.ParseCSV)

			// Защищенные маршруты (с авторизацией)
			protected := products.Group("")
			protected.Use(handlers.AuthMiddleware())
			{
				protected.POST("/products.php", handlers.CreateProducts)
				protected.PUT("/products.php/:id", handlers.UpdateProduct)
				protected.DELETE("/products.php/:id", handlers.DeleteProduct)
			}
		}
	}

	// Альтернативные маршруты для совместимости
	router.GET("/v1/products/products.php", handlers.ListProducts)
	router.GET("/v1/products/products.php/:id", handlers.GetProduct)
	router.POST("/v1/products/products.php", handlers.AuthMiddleware(), handlers.CreateProducts)
	router.PUT("/v1/products/products.php/:id", handlers.AuthMiddleware(), handlers.UpdateProduct)
	router.DELETE("/v1/products/products.php/:id", handlers.AuthMiddleware(), handlers.DeleteProduct)
	router.GET("/v1/products/parser.php", handlers.ParseCSV)

	// Корневой маршрут для проверки здоровья
	router.GET("/health", func(c *gin.Context) {
		c.JSON(200, gin.H{
			"status": "ok",
			"message": "PortalData API is running",
		})
	})
} 